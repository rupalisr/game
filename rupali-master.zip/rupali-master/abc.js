function validateForm(){
	var a=document.getElementById("pass").value;
	var b=document.getElementById("repass").value;
    var n=document.getElementById("fname").value;
	
	if(a!=b){
	  alert("password should match");
	  
	}
   var info="UserName="+document.getElementById("fname").value+";Paasword="+document.getElementById("fpass").value;
	document.cookie=info;
	
	if(document.cookie.length!=0){
		alert(document.cookie);
	}
	else{
		alert("cookie is not created");
	}
}
/*function setCookie()
	{
	var info="UserName="+document.getElementById("fname").value+";Paasword="+document.getElementById("fpass").value;
	document.cookie=info;
}
function getCookie(){
	if(document.cookie.length!=0){
		alert(document.cookie);
	}
	else{
		alert("cookie is not created");
	}
}*/